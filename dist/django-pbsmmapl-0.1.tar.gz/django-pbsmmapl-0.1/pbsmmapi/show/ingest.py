
def process_show_record(obj, instance):
    pass